@echo off

ren "DevilMayCry4SpecialEdition.exe" "__prime_DevilMayCry4SpecialEdition.exe"
ren "steam_api.dll"                  "__prime_steam_api.dll"

xdelta3-3.0.11-x86_64.exe -d -s "__prime_DevilMayCry4SpecialEdition.exe" "__new_diff_DevilMayCry4SpecialEdition.exe.bin" "DevilMayCry4SpecialEdition.exe"
xdelta3-3.0.11-x86_64.exe -d -s "__prime_steam_api.dll"                  "__new_diff_steam_api.dll.bin"                  "steam_api.dll"
